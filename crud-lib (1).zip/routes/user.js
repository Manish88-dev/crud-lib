const express = require("express");

const User = require("../models/users");

const { generateKeyPairSync, sign } = require('crypto');


const router = express.Router();


router.post('/', async (req, res) => {
    try {
        const user = new User(req.body);

        const keypair = generateKeyPairSync('ED25519', {
            modulusLength: 570,
            publicKeyEncoding: {
                type: 'spki',
                format: 'der'
            },
            privateKeyEncoding: {
                type: 'pkcs8',
                format: 'der'
            }
        });
        const publicKey = keypair.publicKey.toString('base64');
        const privateKey = keypair.privateKey.toString('base64');
        user.publicKey = publicKey;

        const createUser = await user.save();
        res.status(201).send({ createUser, privateKey });
    } catch (err) {
        res.status(400).send(err);
    }
});

router.post('/create-signature', (req, res) => {
    try {
        // Using Hashing Algorithm
        const { data, privateKey } = req.body;
        const bffData = Buffer.from(data);
        const buffPriKey = Buffer.from(privateKey);
        const signature = sign("SHA256", bffData, buffPriKey);

        res.status(201).send(signature);
    } catch (err) {
        res.status(400).send(err);
    }
});

router.post('/verify', async (req, res) => {
    try {
        // Using Hashing Algorithm
        const algorithm = "ed25519";
        const { userId, data, signature } = req.body
        const user = User.findById(userId);
        if (!user) {
            return res.status(400).send("user not found");
        }
        const isVerified = crypto.verify(algorithm, Buffer.from(data), Buffer.from(user.publicKey), Buffer.from(signature));
        res.status(201).send(isVerified);
    } catch (err) {
        res.status(400).send(err);
    }
});

module.exports = router;