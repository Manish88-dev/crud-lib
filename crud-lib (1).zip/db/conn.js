// include mongoose
const mongoose = require('mongoose');

// connection url
const connUri = process.env.DATABASE;

// function to connect database to backend
const connectToMongo = () => {
    mongoose
        .connect(connUri)
        .then(() => console.log('Connection Successfull....'))
        .catch((err) => console.log(err));
};

// export connection function
module.exports = connectToMongo;
